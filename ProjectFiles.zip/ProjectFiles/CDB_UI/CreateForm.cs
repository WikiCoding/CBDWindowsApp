﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using Teste_CBD_Library;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace CDB_UI
{
    public partial class CreateForm : Form
    {
        List<CustomerModel> CustomerEntry = SaveProcessor.LoadCustomersFile().ConvertToCustomerModels();
        List<ProjectsModel> Projects = new();
        List<ProjectsModel> projList = SaveProcessor.LoadProjectsFile().ConvertToProjectModels();

        public CreateForm()
        {
            InitializeComponent();

            WireUpLists();
        }

        private void WireUpLists()
        {
            CustomerEntry = CustomerEntry.OrderBy(x => x.Name).ToList();
            customerProjListBox.DataSource = null;
            customerProjListBox.DataSource = Projects;
            customerProjListBox.DisplayMember = "DisplayData";

            projList = projList.OrderBy(x => x.ProjNum).ToList();
            availableProjDropDown.DataSource = projList;
            availableProjDropDown.DisplayMember = "ProjectsIdName";

        }

        private void createProj_Click(object sender, EventArgs e)
        {
            ProjectsModel model = new ProjectsModel();
            
            int currentId = 1;
            if (projList.Count > 0)
            {
                currentId = projList.OrderByDescending(x => x.ProjId).First().ProjId + 1;
            }
            
            model.ProjId = currentId;
            model.ProjNum = projNumvalue.Text;
            model.ProjName = projNameValue.Text;
            model.registryTime = DateTime.Now.ToString();

            //proteger aqui a introdução de valor
            if (ValidateForm())
            {
                if (model.Price <= 0)
                {
                    model.Price = decimal.Parse(priceValue.Text);
                }
            }
            else
            {
                MessageBox.Show("You need to fill in a number or maybe use a comma separator instead");
                return;
            }

            if (model.ProjNum.Length > 0 && model.ProjName.Length > 0)
            {
                //aqui adiciona à ListBox
                Projects.Add(model);

                //aqui adiciona à lista a gravar
                projList.Add(model);

                WireUpLists();

                projList.SaveToProjectsFile();

                projNumvalue.Text = "";
                projNameValue.Text = "";
                priceValue.Text = "";
            }
            else
            {
                MessageBox.Show("You need to fill in all the Project Related Fields");
            }
            
        }

        private bool ValidateForm()
        {
            bool output = true;

            decimal priceAmount = 0;
            bool priceAmountValid = decimal.TryParse(priceValue.Text, out priceAmount);
            if (!priceAmountValid)
            {
                output = false;
            }

            return output;
        }

        private void createEntryButton_Click(object sender, EventArgs e)
        {
            CustomerModel customer = new();
            List<CustomerModel> customerList = SaveProcessor.LoadCustomersFile().ConvertToCustomerModels();

            int currentId = 1;
            if (customerList.Count > 0)
            {
                currentId = customerList.OrderByDescending(x => x.Id).First().Id + 1;
            }
            customer.Id = currentId;

            string noValue = "0";

            //Aqui era um bom momento para usar switch case....
            if (customerNameValue.Text != "") { customer.Name = customerNameValue.Text; }
            else {
                MessageBox.Show("You need to add at least a Customer Name."); 
                    return; }

            if (customerAddressValue.Text != "") { customer.Address = customerAddressValue.Text; }
            else { customer.Address = noValue; }

            if (phoneValue.Text != "") { customer.Phone = phoneValue.Text; }
            else { customer.Phone = noValue; }

            if (emailValue.Text != "") { customer.Email = emailValue.Text; }
            else { customer.Email = noValue; }

            if (customerNIFValue.Text != "") { customer.NIF = customerNIFValue.Text; }
            else { customer.NIF = noValue; }
            
            customer.ProjectList = Projects;

            //Só grava se tiver projetos
            if (customerProjListBox.Items.Count > 0)
            {
                CustomerEntry.Add(customer);

                CustomerEntry.SaveToCustomerFile();

                this.Close();
            }
            else
            {
                MessageBox.Show("You need to assign a Project to create a Customer");
            }
        }

        private void moveAvailableButton_Click(object sender, EventArgs e)
        {
            ProjectsModel pm = (ProjectsModel)availableProjDropDown.SelectedItem;
            Projects.Add(pm);

            WireUpLists();
        }

        private void rmvSelected_Click(object sender, EventArgs e)
        {
            ProjectsModel rmv = (ProjectsModel)customerProjListBox.SelectedItem;
            Projects.Remove(rmv);

            WireUpLists();
        }
    }
}
