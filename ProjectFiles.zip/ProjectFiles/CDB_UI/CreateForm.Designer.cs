﻿namespace CDB_UI
{
    partial class CreateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.projNumLabel = new System.Windows.Forms.Label();
            this.priceValue = new System.Windows.Forms.TextBox();
            this.projNameValue = new System.Windows.Forms.TextBox();
            this.projNumvalue = new System.Windows.Forms.TextBox();
            this.createProj = new System.Windows.Forms.Button();
            this.customerNameLabel = new System.Windows.Forms.Label();
            this.customerNameValue = new System.Windows.Forms.TextBox();
            this.createEntryButton = new System.Windows.Forms.Button();
            this.customerAddressLabel = new System.Windows.Forms.Label();
            this.customerAddressValue = new System.Windows.Forms.TextBox();
            this.customerNIFlabel = new System.Windows.Forms.Label();
            this.customerNIFValue = new System.Windows.Forms.TextBox();
            this.customerProjListBox = new System.Windows.Forms.ListBox();
            this.phoneLabel = new System.Windows.Forms.Label();
            this.phoneValue = new System.Windows.Forms.TextBox();
            this.emailLabel = new System.Windows.Forms.Label();
            this.emailValue = new System.Windows.Forms.TextBox();
            this.moveAvailableButton = new System.Windows.Forms.Button();
            this.availableProjDropDown = new System.Windows.Forms.ComboBox();
            this.rmvSelected = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(806, 297);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 32);
            this.label2.TabIndex = 13;
            this.label2.Text = "P. Price";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(806, 194);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 32);
            this.label1.TabIndex = 12;
            this.label1.Text = "P. Name";
            // 
            // projNumLabel
            // 
            this.projNumLabel.AutoSize = true;
            this.projNumLabel.Location = new System.Drawing.Point(806, 112);
            this.projNumLabel.Name = "projNumLabel";
            this.projNumLabel.Size = new System.Drawing.Size(127, 32);
            this.projNumLabel.TabIndex = 11;
            this.projNumLabel.Text = "P. Number";
            // 
            // priceValue
            // 
            this.priceValue.Location = new System.Drawing.Point(964, 290);
            this.priceValue.Name = "priceValue";
            this.priceValue.Size = new System.Drawing.Size(255, 39);
            this.priceValue.TabIndex = 10;
            // 
            // projNameValue
            // 
            this.projNameValue.Location = new System.Drawing.Point(964, 191);
            this.projNameValue.Name = "projNameValue";
            this.projNameValue.Size = new System.Drawing.Size(255, 39);
            this.projNameValue.TabIndex = 9;
            // 
            // projNumvalue
            // 
            this.projNumvalue.Location = new System.Drawing.Point(964, 109);
            this.projNumvalue.Name = "projNumvalue";
            this.projNumvalue.Size = new System.Drawing.Size(255, 39);
            this.projNumvalue.TabIndex = 8;
            // 
            // createProj
            // 
            this.createProj.Location = new System.Drawing.Point(964, 379);
            this.createProj.Name = "createProj";
            this.createProj.Size = new System.Drawing.Size(242, 87);
            this.createProj.TabIndex = 7;
            this.createProj.Text = "Create Project Entry";
            this.createProj.UseVisualStyleBackColor = true;
            this.createProj.Click += new System.EventHandler(this.createProj_Click);
            // 
            // customerNameLabel
            // 
            this.customerNameLabel.AutoSize = true;
            this.customerNameLabel.Location = new System.Drawing.Point(12, 59);
            this.customerNameLabel.Name = "customerNameLabel";
            this.customerNameLabel.Size = new System.Drawing.Size(105, 32);
            this.customerNameLabel.TabIndex = 16;
            this.customerNameLabel.Text = "C. Name";
            // 
            // customerNameValue
            // 
            this.customerNameValue.Location = new System.Drawing.Point(170, 56);
            this.customerNameValue.Name = "customerNameValue";
            this.customerNameValue.Size = new System.Drawing.Size(581, 39);
            this.customerNameValue.TabIndex = 15;
            // 
            // createEntryButton
            // 
            this.createEntryButton.Location = new System.Drawing.Point(527, 535);
            this.createEntryButton.Name = "createEntryButton";
            this.createEntryButton.Size = new System.Drawing.Size(242, 87);
            this.createEntryButton.TabIndex = 14;
            this.createEntryButton.Text = "Create Entry";
            this.createEntryButton.UseVisualStyleBackColor = true;
            this.createEntryButton.Click += new System.EventHandler(this.createEntryButton_Click);
            // 
            // customerAddressLabel
            // 
            this.customerAddressLabel.AutoSize = true;
            this.customerAddressLabel.Location = new System.Drawing.Point(12, 125);
            this.customerAddressLabel.Name = "customerAddressLabel";
            this.customerAddressLabel.Size = new System.Drawing.Size(125, 32);
            this.customerAddressLabel.TabIndex = 18;
            this.customerAddressLabel.Text = "C. Address";
            // 
            // customerAddressValue
            // 
            this.customerAddressValue.Location = new System.Drawing.Point(170, 122);
            this.customerAddressValue.Name = "customerAddressValue";
            this.customerAddressValue.Size = new System.Drawing.Size(581, 39);
            this.customerAddressValue.TabIndex = 17;
            // 
            // customerNIFlabel
            // 
            this.customerNIFlabel.AutoSize = true;
            this.customerNIFlabel.Location = new System.Drawing.Point(12, 320);
            this.customerNIFlabel.Name = "customerNIFlabel";
            this.customerNIFlabel.Size = new System.Drawing.Size(77, 32);
            this.customerNIFlabel.TabIndex = 20;
            this.customerNIFlabel.Text = "C. NIF";
            // 
            // customerNIFValue
            // 
            this.customerNIFValue.Location = new System.Drawing.Point(170, 317);
            this.customerNIFValue.Name = "customerNIFValue";
            this.customerNIFValue.Size = new System.Drawing.Size(581, 39);
            this.customerNIFValue.TabIndex = 19;
            // 
            // customerProjListBox
            // 
            this.customerProjListBox.FormattingEnabled = true;
            this.customerProjListBox.ItemHeight = 31;
            this.customerProjListBox.Location = new System.Drawing.Point(24, 388);
            this.customerProjListBox.Name = "customerProjListBox";
            this.customerProjListBox.Size = new System.Drawing.Size(727, 128);
            this.customerProjListBox.TabIndex = 21;
            // 
            // phoneLabel
            // 
            this.phoneLabel.AutoSize = true;
            this.phoneLabel.Location = new System.Drawing.Point(12, 193);
            this.phoneLabel.Name = "phoneLabel";
            this.phoneLabel.Size = new System.Drawing.Size(109, 32);
            this.phoneLabel.TabIndex = 23;
            this.phoneLabel.Text = "C. Phone";
            // 
            // phoneValue
            // 
            this.phoneValue.Location = new System.Drawing.Point(170, 190);
            this.phoneValue.Name = "phoneValue";
            this.phoneValue.Size = new System.Drawing.Size(581, 39);
            this.phoneValue.TabIndex = 22;
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(12, 258);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(98, 32);
            this.emailLabel.TabIndex = 25;
            this.emailLabel.Text = "C. Email";
            // 
            // emailValue
            // 
            this.emailValue.Location = new System.Drawing.Point(170, 255);
            this.emailValue.Name = "emailValue";
            this.emailValue.Size = new System.Drawing.Size(581, 39);
            this.emailValue.TabIndex = 24;
            // 
            // moveAvailableButton
            // 
            this.moveAvailableButton.Location = new System.Drawing.Point(856, 559);
            this.moveAvailableButton.Name = "moveAvailableButton";
            this.moveAvailableButton.Size = new System.Drawing.Size(350, 63);
            this.moveAvailableButton.TabIndex = 40;
            this.moveAvailableButton.Text = "Move Available Project to List";
            this.moveAvailableButton.UseVisualStyleBackColor = true;
            this.moveAvailableButton.Click += new System.EventHandler(this.moveAvailableButton_Click);
            // 
            // availableProjDropDown
            // 
            this.availableProjDropDown.FormattingEnabled = true;
            this.availableProjDropDown.Location = new System.Drawing.Point(856, 514);
            this.availableProjDropDown.Name = "availableProjDropDown";
            this.availableProjDropDown.Size = new System.Drawing.Size(350, 39);
            this.availableProjDropDown.TabIndex = 39;
            // 
            // rmvSelected
            // 
            this.rmvSelected.Location = new System.Drawing.Point(24, 522);
            this.rmvSelected.Name = "rmvSelected";
            this.rmvSelected.Size = new System.Drawing.Size(350, 63);
            this.rmvSelected.TabIndex = 41;
            this.rmvSelected.Text = "Remove Selected Project";
            this.rmvSelected.UseVisualStyleBackColor = true;
            this.rmvSelected.Click += new System.EventHandler(this.rmvSelected_Click);
            // 
            // CreateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1273, 648);
            this.Controls.Add(this.rmvSelected);
            this.Controls.Add(this.moveAvailableButton);
            this.Controls.Add(this.availableProjDropDown);
            this.Controls.Add(this.emailLabel);
            this.Controls.Add(this.emailValue);
            this.Controls.Add(this.phoneLabel);
            this.Controls.Add(this.phoneValue);
            this.Controls.Add(this.customerProjListBox);
            this.Controls.Add(this.customerNIFlabel);
            this.Controls.Add(this.customerNIFValue);
            this.Controls.Add(this.customerAddressLabel);
            this.Controls.Add(this.customerAddressValue);
            this.Controls.Add(this.customerNameLabel);
            this.Controls.Add(this.customerNameValue);
            this.Controls.Add(this.createEntryButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.projNumLabel);
            this.Controls.Add(this.priceValue);
            this.Controls.Add(this.projNameValue);
            this.Controls.Add(this.projNumvalue);
            this.Controls.Add(this.createProj);
            this.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "CreateForm";
            this.Text = "Create Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label2;
        private Label label1;
        private Label projNumLabel;
        private TextBox priceValue;
        private TextBox projNameValue;
        private TextBox projNumvalue;
        private Button createProj;
        private Label customerNameLabel;
        private TextBox customerNameValue;
        private Button createEntryButton;
        private Label customerAddressLabel;
        private TextBox customerAddressValue;
        private Label customerNIFlabel;
        private TextBox customerNIFValue;
        private ListBox customerProjListBox;
        private Label phoneLabel;
        private TextBox phoneValue;
        private Label emailLabel;
        private TextBox emailValue;
        private Button moveAvailableButton;
        private ComboBox availableProjDropDown;
        private Button rmvSelected;
    }
}