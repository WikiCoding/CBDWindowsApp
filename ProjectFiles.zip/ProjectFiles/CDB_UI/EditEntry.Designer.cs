﻿namespace CDB_UI
{
    partial class EditEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ProjListBox = new System.Windows.Forms.ListBox();
            this.customerNIFlabel = new System.Windows.Forms.Label();
            this.cNIFValue = new System.Windows.Forms.TextBox();
            this.customerAddressLabel = new System.Windows.Forms.Label();
            this.cAddressValue = new System.Windows.Forms.TextBox();
            this.customerNameLabel = new System.Windows.Forms.Label();
            this.cNameValue = new System.Windows.Forms.TextBox();
            this.saveChangesButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.projNumLabel = new System.Windows.Forms.Label();
            this.priceValue = new System.Windows.Forms.TextBox();
            this.projNameValue = new System.Windows.Forms.TextBox();
            this.projNumvalue = new System.Windows.Forms.TextBox();
            this.AddProj = new System.Windows.Forms.Button();
            this.availableProjDropDown = new System.Windows.Forms.ComboBox();
            this.moveAvailableButton = new System.Windows.Forms.Button();
            this.emailLabel = new System.Windows.Forms.Label();
            this.emailValue = new System.Windows.Forms.TextBox();
            this.phoneLabel = new System.Windows.Forms.Label();
            this.phoneValue = new System.Windows.Forms.TextBox();
            this.removeSelectedProject = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ProjListBox
            // 
            this.ProjListBox.FormattingEnabled = true;
            this.ProjListBox.ItemHeight = 31;
            this.ProjListBox.Location = new System.Drawing.Point(51, 414);
            this.ProjListBox.Name = "ProjListBox";
            this.ProjListBox.Size = new System.Drawing.Size(727, 128);
            this.ProjListBox.TabIndex = 36;
            // 
            // customerNIFlabel
            // 
            this.customerNIFlabel.AutoSize = true;
            this.customerNIFlabel.Location = new System.Drawing.Point(39, 351);
            this.customerNIFlabel.Name = "customerNIFlabel";
            this.customerNIFlabel.Size = new System.Drawing.Size(77, 32);
            this.customerNIFlabel.TabIndex = 35;
            this.customerNIFlabel.Text = "C. NIF";
            // 
            // cNIFValue
            // 
            this.cNIFValue.Location = new System.Drawing.Point(197, 348);
            this.cNIFValue.Name = "cNIFValue";
            this.cNIFValue.Size = new System.Drawing.Size(581, 39);
            this.cNIFValue.TabIndex = 34;
            // 
            // customerAddressLabel
            // 
            this.customerAddressLabel.AutoSize = true;
            this.customerAddressLabel.Location = new System.Drawing.Point(39, 154);
            this.customerAddressLabel.Name = "customerAddressLabel";
            this.customerAddressLabel.Size = new System.Drawing.Size(125, 32);
            this.customerAddressLabel.TabIndex = 33;
            this.customerAddressLabel.Text = "C. Address";
            // 
            // cAddressValue
            // 
            this.cAddressValue.Location = new System.Drawing.Point(197, 151);
            this.cAddressValue.Name = "cAddressValue";
            this.cAddressValue.Size = new System.Drawing.Size(581, 39);
            this.cAddressValue.TabIndex = 32;
            // 
            // customerNameLabel
            // 
            this.customerNameLabel.AutoSize = true;
            this.customerNameLabel.Location = new System.Drawing.Point(39, 79);
            this.customerNameLabel.Name = "customerNameLabel";
            this.customerNameLabel.Size = new System.Drawing.Size(105, 32);
            this.customerNameLabel.TabIndex = 31;
            this.customerNameLabel.Text = "C. Name";
            // 
            // cNameValue
            // 
            this.cNameValue.Location = new System.Drawing.Point(197, 76);
            this.cNameValue.Name = "cNameValue";
            this.cNameValue.Size = new System.Drawing.Size(581, 39);
            this.cNameValue.TabIndex = 30;
            // 
            // saveChangesButton
            // 
            this.saveChangesButton.Location = new System.Drawing.Point(536, 555);
            this.saveChangesButton.Name = "saveChangesButton";
            this.saveChangesButton.Size = new System.Drawing.Size(242, 87);
            this.saveChangesButton.TabIndex = 29;
            this.saveChangesButton.Text = "Save Changes";
            this.saveChangesButton.UseVisualStyleBackColor = true;
            this.saveChangesButton.Click += new System.EventHandler(this.saveChangesButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(833, 260);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 32);
            this.label2.TabIndex = 28;
            this.label2.Text = "P. Price";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(833, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 32);
            this.label1.TabIndex = 27;
            this.label1.Text = "P. Name";
            // 
            // projNumLabel
            // 
            this.projNumLabel.AutoSize = true;
            this.projNumLabel.Location = new System.Drawing.Point(833, 75);
            this.projNumLabel.Name = "projNumLabel";
            this.projNumLabel.Size = new System.Drawing.Size(127, 32);
            this.projNumLabel.TabIndex = 26;
            this.projNumLabel.Text = "P. Number";
            // 
            // priceValue
            // 
            this.priceValue.Location = new System.Drawing.Point(991, 253);
            this.priceValue.Name = "priceValue";
            this.priceValue.Size = new System.Drawing.Size(255, 39);
            this.priceValue.TabIndex = 25;
            // 
            // projNameValue
            // 
            this.projNameValue.Location = new System.Drawing.Point(991, 154);
            this.projNameValue.Name = "projNameValue";
            this.projNameValue.Size = new System.Drawing.Size(255, 39);
            this.projNameValue.TabIndex = 24;
            // 
            // projNumvalue
            // 
            this.projNumvalue.Location = new System.Drawing.Point(991, 72);
            this.projNumvalue.Name = "projNumvalue";
            this.projNumvalue.Size = new System.Drawing.Size(255, 39);
            this.projNumvalue.TabIndex = 23;
            // 
            // AddProj
            // 
            this.AddProj.Location = new System.Drawing.Point(991, 342);
            this.AddProj.Name = "AddProj";
            this.AddProj.Size = new System.Drawing.Size(242, 87);
            this.AddProj.TabIndex = 22;
            this.AddProj.Text = "Add Project Entry";
            this.AddProj.UseVisualStyleBackColor = true;
            this.AddProj.Click += new System.EventHandler(this.AddProj_Click);
            // 
            // availableProjDropDown
            // 
            this.availableProjDropDown.FormattingEnabled = true;
            this.availableProjDropDown.Location = new System.Drawing.Point(896, 461);
            this.availableProjDropDown.Name = "availableProjDropDown";
            this.availableProjDropDown.Size = new System.Drawing.Size(350, 39);
            this.availableProjDropDown.TabIndex = 37;
            // 
            // moveAvailableButton
            // 
            this.moveAvailableButton.Location = new System.Drawing.Point(896, 506);
            this.moveAvailableButton.Name = "moveAvailableButton";
            this.moveAvailableButton.Size = new System.Drawing.Size(350, 63);
            this.moveAvailableButton.TabIndex = 38;
            this.moveAvailableButton.Text = "Move Available Project to List";
            this.moveAvailableButton.UseVisualStyleBackColor = true;
            this.moveAvailableButton.Click += new System.EventHandler(this.moveAvailableButton_Click);
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(39, 283);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(98, 32);
            this.emailLabel.TabIndex = 42;
            this.emailLabel.Text = "C. Email";
            // 
            // emailValue
            // 
            this.emailValue.Location = new System.Drawing.Point(197, 280);
            this.emailValue.Name = "emailValue";
            this.emailValue.Size = new System.Drawing.Size(581, 39);
            this.emailValue.TabIndex = 41;
            // 
            // phoneLabel
            // 
            this.phoneLabel.AutoSize = true;
            this.phoneLabel.Location = new System.Drawing.Point(39, 218);
            this.phoneLabel.Name = "phoneLabel";
            this.phoneLabel.Size = new System.Drawing.Size(109, 32);
            this.phoneLabel.TabIndex = 40;
            this.phoneLabel.Text = "C. Phone";
            // 
            // phoneValue
            // 
            this.phoneValue.Location = new System.Drawing.Point(197, 215);
            this.phoneValue.Name = "phoneValue";
            this.phoneValue.Size = new System.Drawing.Size(581, 39);
            this.phoneValue.TabIndex = 39;
            // 
            // removeSelectedProject
            // 
            this.removeSelectedProject.Location = new System.Drawing.Point(51, 555);
            this.removeSelectedProject.Name = "removeSelectedProject";
            this.removeSelectedProject.Size = new System.Drawing.Size(423, 87);
            this.removeSelectedProject.TabIndex = 43;
            this.removeSelectedProject.Text = "Remove Selected Project";
            this.removeSelectedProject.UseVisualStyleBackColor = true;
            this.removeSelectedProject.Click += new System.EventHandler(this.removeSelectedProject_Click);
            // 
            // EditEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1285, 657);
            this.Controls.Add(this.removeSelectedProject);
            this.Controls.Add(this.emailLabel);
            this.Controls.Add(this.emailValue);
            this.Controls.Add(this.phoneLabel);
            this.Controls.Add(this.phoneValue);
            this.Controls.Add(this.moveAvailableButton);
            this.Controls.Add(this.availableProjDropDown);
            this.Controls.Add(this.ProjListBox);
            this.Controls.Add(this.customerNIFlabel);
            this.Controls.Add(this.cNIFValue);
            this.Controls.Add(this.customerAddressLabel);
            this.Controls.Add(this.cAddressValue);
            this.Controls.Add(this.customerNameLabel);
            this.Controls.Add(this.cNameValue);
            this.Controls.Add(this.saveChangesButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.projNumLabel);
            this.Controls.Add(this.priceValue);
            this.Controls.Add(this.projNameValue);
            this.Controls.Add(this.projNumvalue);
            this.Controls.Add(this.AddProj);
            this.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "EditEntry";
            this.Text = "Edit Entry";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ListBox ProjListBox;
        private Label customerNIFlabel;
        private TextBox cNIFValue;
        private Label customerAddressLabel;
        private TextBox cAddressValue;
        private Label customerNameLabel;
        private TextBox cNameValue;
        private Button saveChangesButton;
        private Label label2;
        private Label label1;
        private Label projNumLabel;
        private TextBox priceValue;
        private TextBox projNameValue;
        private TextBox projNumvalue;
        private Button AddProj;
        private ComboBox availableProjDropDown;
        private Button moveAvailableButton;
        private Label emailLabel;
        private TextBox emailValue;
        private Label phoneLabel;
        private TextBox phoneValue;
        private Button removeSelectedProject;
    }
}