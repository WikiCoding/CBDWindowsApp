﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Teste_CBD_Library;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace CDB_UI
{
    public partial class EditEntry : Form
    {
        private CustomerModel customerModel;
        List<ProjectsModel> Projects = new();
        List<ProjectsModel> projList = SaveProcessor.LoadProjectsFile().ConvertToProjectModels();
        List<string> Customers = SaveProcessor.LoadCustomersFile();
                
        public EditEntry(CustomerModel model)
        {
            InitializeComponent();
            customerModel = model;
            Projects = customerModel.ProjectList;
            ListInfo();
        }
        
        private void ListInfo()
        {
            cNameValue.Text = customerModel.Name;
            cAddressValue.Text = customerModel.Address;
            phoneValue.Text = customerModel.Phone;
            emailValue.Text = customerModel.Email;
            cNIFValue.Text = customerModel.NIF;

            ProjListBox.DataSource = customerModel.ProjectList;
            ProjListBox.DisplayMember = "DisplayData";

            projList = projList.OrderBy(q => q.ProjNum).ToList();

            availableProjDropDown.DataSource = projList;
            availableProjDropDown.DisplayMember = "ProjectsIdName";

        }
        
        private void WireUpLists()
        {
            Projects = Projects.OrderBy(x => x.ProjNum).ToList();
            ProjListBox.DataSource = null;
            ProjListBox.DataSource = Projects;
            ProjListBox.DisplayMember = "DisplayData";
            
        }

        private void AddProj_Click(object sender, EventArgs e)
        {
            
            ProjectsModel model = new ProjectsModel();

            int currentId = 1;
            if (projList.Count > 0)
            {
                currentId = projList.OrderByDescending(x => x.ProjId).First().ProjId + 1;
            }
            model.ProjId = currentId;
                
            if (ValidateForm())
            {
                if (model.Price <= 0)
                {
                    model.Price = decimal.Parse(priceValue.Text);
                }
            }

            else
            {
                MessageBox.Show("You need to fill in a number or maybe use a comma separator instead");
            }
            model.ProjNum = projNumvalue.Text;
            model.ProjName = projNameValue.Text;
            model.registryTime = DateTime.Now.ToString();

            if (model.ProjNum.Length > 0 && model.ProjName.Length > 0)
            {
                //aqui adiciona à ListBox
                Projects.Add(model);

                //aqui adiciona à lista a gravar
                projList.Add(model);

                WireUpLists();

                projList.SaveToProjectsFile();

                projNumvalue.Text = "";
                projNameValue.Text = "";
                priceValue.Text = "";
            }
            else
            {
                MessageBox.Show("You need to fill in all the Project Related Fields");
            }
        }
        private bool ValidateForm()
        {
            bool output = true;

            decimal priceAmount = 0;
            bool priceAmountValid = decimal.TryParse(priceValue.Text, out priceAmount);
            if (!priceAmountValid)
            {
                output = false;
            }

            return output;
        }

        private void saveChangesButton_Click(object sender, EventArgs e)
        {
            if (ProjListBox.Items.Count > 0)
            {
                CustomerModel customer = new();
                
                customer.Id = customerModel.Id;
                customer.Name = cNameValue.Text;
                customer.Address = cAddressValue.Text;
                customer.Phone = phoneValue.Text;
                customer.Email = emailValue.Text;
                customer.NIF = cNIFValue.Text;

                List<ProjectsModel> projectsList = new();

                for (int i = 0; i < ProjListBox.Items.Count; i++)
                {
                    projectsList = Projects;
                }

                customer.ProjectList = projectsList;

                DeleteSelected();
                List<CustomerModel> savedCustomerList = SaveProcessor.LoadCustomersFile().ConvertToCustomerModels();
                //ao inicializar aqui a lista já vou ler diretamente a lista após remoção do Item antigo que foi editado.
                savedCustomerList.Add(customer);
                savedCustomerList.Sort((a, b) => (a.Id > b.Id) ? 1: -1);
                savedCustomerList.SaveToCustomerFile();
                
                this.Close();
            }
            else
            {
                MessageBox.Show("You need to assign at least one Project first to Edit a customer");
            }
        }

        private void moveAvailableButton_Click(object sender, EventArgs e)
        {
            ProjectsModel pm = (ProjectsModel)availableProjDropDown.SelectedItem;
            Projects.Add(pm);

            WireUpLists();
        }

        private void DeleteSelected()
        {
            string name = customerModel.Name;

            int counter = 0;
            List<string> lines = SaveProcessor.LoadCustomersFile();

            int lineNumber = 0;
            // Read the file and display it line by line.
            foreach (string line in lines)
            {
                string[] cols = line.Split('|');

                if (line.Contains($"|{name}|"))
                {
                    lineNumber = counter;
                }
                counter++;

            }

            lines.RemoveAt(lineNumber);
            File.WriteAllLines(SaveProcessor.CustomersFilePath(), lines.ToArray());
            
        }
        private void removeSelectedProject_Click(object sender, EventArgs e)
        {
            ProjectsModel rmv = (ProjectsModel)ProjListBox.SelectedItem;
            Projects.Remove(rmv);

            WireUpLists();
        }
    }
}
