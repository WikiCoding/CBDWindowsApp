﻿namespace CDB_UI
{
    partial class DatabaseDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.createEntry = new System.Windows.Forms.Button();
            this.loadSelectedDetails = new System.Windows.Forms.Button();
            this.custListBox = new System.Windows.Forms.ListBox();
            this.customerNameLabel = new System.Windows.Forms.Label();
            this.customerNameValue = new System.Windows.Forms.Label();
            this.customerAddressValue = new System.Windows.Forms.Label();
            this.customerAdressLabel = new System.Windows.Forms.Label();
            this.customerNIFValue = new System.Windows.Forms.Label();
            this.customerNIFLAbel = new System.Windows.Forms.Label();
            this.customerProjectsListBox = new System.Windows.Forms.ListBox();
            this.customerProjectsLabel = new System.Windows.Forms.Label();
            this.refreshListButton = new System.Windows.Forms.Button();
            this.editButton = new System.Windows.Forms.Button();
            this.totalPruchasesLabel = new System.Windows.Forms.Label();
            this.totalPurchasesValue = new System.Windows.Forms.Label();
            this.projectsListBox = new System.Windows.Forms.ListBox();
            this.refreshProjButton = new System.Windows.Forms.Button();
            this.findCustomerButton = new System.Windows.Forms.Button();
            this.deleteSelected = new System.Windows.Forms.Button();
            this.deleteSelectedProj = new System.Windows.Forms.Button();
            this.phoneValue = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.emailValue = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.findMeButton = new System.Windows.Forms.Button();
            this.customersGrid = new System.Windows.Forms.DataGridView();
            this.projectsGrid = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.customersGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectsGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // createEntry
            // 
            this.createEntry.AutoEllipsis = true;
            this.createEntry.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.createEntry.Cursor = System.Windows.Forms.Cursors.Hand;
            this.createEntry.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.createEntry.Location = new System.Drawing.Point(940, 505);
            this.createEntry.Name = "createEntry";
            this.createEntry.Padding = new System.Windows.Forms.Padding(10);
            this.createEntry.Size = new System.Drawing.Size(242, 87);
            this.createEntry.TabIndex = 0;
            this.createEntry.Text = "Create New Entry";
            this.createEntry.UseVisualStyleBackColor = false;
            this.createEntry.Click += new System.EventHandler(this.createEntry_Click);
            // 
            // loadSelectedDetails
            // 
            this.loadSelectedDetails.Location = new System.Drawing.Point(12, 523);
            this.loadSelectedDetails.Name = "loadSelectedDetails";
            this.loadSelectedDetails.Size = new System.Drawing.Size(15, 87);
            this.loadSelectedDetails.TabIndex = 1;
            this.loadSelectedDetails.Text = "Load Selected Details";
            this.loadSelectedDetails.UseVisualStyleBackColor = true;
            this.loadSelectedDetails.Visible = false;
            this.loadSelectedDetails.Click += new System.EventHandler(this.loadSelectedDetails_Click);
            // 
            // custListBox
            // 
            this.custListBox.FormattingEnabled = true;
            this.custListBox.HorizontalScrollbar = true;
            this.custListBox.ItemHeight = 31;
            this.custListBox.Location = new System.Drawing.Point(31, 30);
            this.custListBox.Name = "custListBox";
            this.custListBox.Size = new System.Drawing.Size(416, 469);
            this.custListBox.TabIndex = 2;
            this.custListBox.SelectedIndexChanged += new System.EventHandler(this.custListBox_SelectedIndexChanged);
            // 
            // customerNameLabel
            // 
            this.customerNameLabel.AutoSize = true;
            this.customerNameLabel.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.customerNameLabel.Location = new System.Drawing.Point(940, 30);
            this.customerNameLabel.Name = "customerNameLabel";
            this.customerNameLabel.Size = new System.Drawing.Size(77, 31);
            this.customerNameLabel.TabIndex = 3;
            this.customerNameLabel.Text = "Name";
            // 
            // customerNameValue
            // 
            this.customerNameValue.AutoSize = true;
            this.customerNameValue.Location = new System.Drawing.Point(1068, 30);
            this.customerNameValue.Name = "customerNameValue";
            this.customerNameValue.Size = new System.Drawing.Size(110, 32);
            this.customerNameValue.TabIndex = 4;
            this.customerNameValue.Text = "<Name>";
            // 
            // customerAddressValue
            // 
            this.customerAddressValue.AutoSize = true;
            this.customerAddressValue.Location = new System.Drawing.Point(1068, 79);
            this.customerAddressValue.Name = "customerAddressValue";
            this.customerAddressValue.Size = new System.Drawing.Size(130, 32);
            this.customerAddressValue.TabIndex = 6;
            this.customerAddressValue.Text = "<Address>";
            // 
            // customerAdressLabel
            // 
            this.customerAdressLabel.AutoSize = true;
            this.customerAdressLabel.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.customerAdressLabel.Location = new System.Drawing.Point(940, 79);
            this.customerAdressLabel.Name = "customerAdressLabel";
            this.customerAdressLabel.Size = new System.Drawing.Size(99, 31);
            this.customerAdressLabel.TabIndex = 5;
            this.customerAdressLabel.Text = "Address";
            // 
            // customerNIFValue
            // 
            this.customerNIFValue.AutoSize = true;
            this.customerNIFValue.Location = new System.Drawing.Point(1068, 214);
            this.customerNIFValue.Name = "customerNIFValue";
            this.customerNIFValue.Size = new System.Drawing.Size(82, 32);
            this.customerNIFValue.TabIndex = 8;
            this.customerNIFValue.Text = "<NIF>";
            // 
            // customerNIFLAbel
            // 
            this.customerNIFLAbel.AutoSize = true;
            this.customerNIFLAbel.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.customerNIFLAbel.Location = new System.Drawing.Point(940, 214);
            this.customerNIFLAbel.Name = "customerNIFLAbel";
            this.customerNIFLAbel.Size = new System.Drawing.Size(51, 31);
            this.customerNIFLAbel.TabIndex = 7;
            this.customerNIFLAbel.Text = "NIF";
            // 
            // customerProjectsListBox
            // 
            this.customerProjectsListBox.FormattingEnabled = true;
            this.customerProjectsListBox.HorizontalScrollbar = true;
            this.customerProjectsListBox.ItemHeight = 31;
            this.customerProjectsListBox.Location = new System.Drawing.Point(940, 340);
            this.customerProjectsListBox.Name = "customerProjectsListBox";
            this.customerProjectsListBox.Size = new System.Drawing.Size(739, 159);
            this.customerProjectsListBox.TabIndex = 9;
            // 
            // customerProjectsLabel
            // 
            this.customerProjectsLabel.AutoSize = true;
            this.customerProjectsLabel.Location = new System.Drawing.Point(940, 303);
            this.customerProjectsLabel.Name = "customerProjectsLabel";
            this.customerProjectsLabel.Size = new System.Drawing.Size(239, 32);
            this.customerProjectsLabel.TabIndex = 10;
            this.customerProjectsLabel.Text = "Customer Project List";
            // 
            // refreshListButton
            // 
            this.refreshListButton.Location = new System.Drawing.Point(453, 523);
            this.refreshListButton.Name = "refreshListButton";
            this.refreshListButton.Size = new System.Drawing.Size(16, 87);
            this.refreshListButton.TabIndex = 11;
            this.refreshListButton.Text = "Refresh";
            this.refreshListButton.UseVisualStyleBackColor = true;
            this.refreshListButton.Visible = false;
            this.refreshListButton.Click += new System.EventHandler(this.refreshListButton_Click);
            // 
            // editButton
            // 
            this.editButton.Location = new System.Drawing.Point(1216, 505);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(279, 87);
            this.editButton.TabIndex = 12;
            this.editButton.Text = "Edit Entry and Projects";
            this.editButton.UseVisualStyleBackColor = true;
            this.editButton.Click += new System.EventHandler(this.editButton_Click);
            // 
            // totalPruchasesLabel
            // 
            this.totalPruchasesLabel.AutoSize = true;
            this.totalPruchasesLabel.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.totalPruchasesLabel.Location = new System.Drawing.Point(940, 259);
            this.totalPruchasesLabel.Name = "totalPruchasesLabel";
            this.totalPruchasesLabel.Size = new System.Drawing.Size(179, 31);
            this.totalPruchasesLabel.TabIndex = 13;
            this.totalPruchasesLabel.Text = "Total Purchases";
            // 
            // totalPurchasesValue
            // 
            this.totalPurchasesValue.AutoSize = true;
            this.totalPurchasesValue.Location = new System.Drawing.Point(1180, 259);
            this.totalPurchasesValue.Name = "totalPurchasesValue";
            this.totalPurchasesValue.Size = new System.Drawing.Size(209, 32);
            this.totalPurchasesValue.TabIndex = 14;
            this.totalPurchasesValue.Text = "<Total Purchases>";
            // 
            // projectsListBox
            // 
            this.projectsListBox.FormattingEnabled = true;
            this.projectsListBox.HorizontalScrollbar = true;
            this.projectsListBox.ItemHeight = 31;
            this.projectsListBox.Location = new System.Drawing.Point(488, 30);
            this.projectsListBox.Name = "projectsListBox";
            this.projectsListBox.Size = new System.Drawing.Size(408, 469);
            this.projectsListBox.TabIndex = 15;
            // 
            // refreshProjButton
            // 
            this.refreshProjButton.Location = new System.Drawing.Point(777, 407);
            this.refreshProjButton.Name = "refreshProjButton";
            this.refreshProjButton.Size = new System.Drawing.Size(103, 87);
            this.refreshProjButton.TabIndex = 16;
            this.refreshProjButton.Text = "Refresh";
            this.refreshProjButton.UseVisualStyleBackColor = true;
            this.refreshProjButton.Visible = false;
            this.refreshProjButton.Click += new System.EventHandler(this.refreshProjButton_Click);
            // 
            // findCustomerButton
            // 
            this.findCustomerButton.Location = new System.Drawing.Point(502, 407);
            this.findCustomerButton.Name = "findCustomerButton";
            this.findCustomerButton.Size = new System.Drawing.Size(137, 87);
            this.findCustomerButton.TabIndex = 17;
            this.findCustomerButton.TabStop = false;
            this.findCustomerButton.Text = "True if in use!";
            this.findCustomerButton.UseVisualStyleBackColor = true;
            this.findCustomerButton.Visible = false;
            this.findCustomerButton.Click += new System.EventHandler(this.findCustomerButton_Click);
            // 
            // deleteSelected
            // 
            this.deleteSelected.Location = new System.Drawing.Point(31, 505);
            this.deleteSelected.Name = "deleteSelected";
            this.deleteSelected.Size = new System.Drawing.Size(416, 87);
            this.deleteSelected.TabIndex = 18;
            this.deleteSelected.Text = "Delete Selected";
            this.deleteSelected.UseVisualStyleBackColor = true;
            this.deleteSelected.Click += new System.EventHandler(this.deleteSelected_Click);
            // 
            // deleteSelectedProj
            // 
            this.deleteSelectedProj.Location = new System.Drawing.Point(488, 505);
            this.deleteSelectedProj.Name = "deleteSelectedProj";
            this.deleteSelectedProj.Size = new System.Drawing.Size(408, 87);
            this.deleteSelectedProj.TabIndex = 19;
            this.deleteSelectedProj.Text = "Delete Selected";
            this.deleteSelectedProj.UseVisualStyleBackColor = true;
            this.deleteSelectedProj.Click += new System.EventHandler(this.deleteSelectedProj_Click);
            // 
            // phoneValue
            // 
            this.phoneValue.AutoSize = true;
            this.phoneValue.Location = new System.Drawing.Point(1068, 123);
            this.phoneValue.Name = "phoneValue";
            this.phoneValue.Size = new System.Drawing.Size(114, 32);
            this.phoneValue.TabIndex = 21;
            this.phoneValue.Text = "<Phone>";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(940, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 31);
            this.label2.TabIndex = 20;
            this.label2.Text = "Phone";
            // 
            // emailValue
            // 
            this.emailValue.AutoSize = true;
            this.emailValue.Location = new System.Drawing.Point(1068, 166);
            this.emailValue.Name = "emailValue";
            this.emailValue.Size = new System.Drawing.Size(103, 32);
            this.emailValue.TabIndex = 23;
            this.emailValue.Text = "<Email>";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(940, 166);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 31);
            this.label4.TabIndex = 22;
            this.label4.Text = "Email";
            // 
            // findMeButton
            // 
            this.findMeButton.Location = new System.Drawing.Point(645, 407);
            this.findMeButton.Name = "findMeButton";
            this.findMeButton.Size = new System.Drawing.Size(126, 87);
            this.findMeButton.TabIndex = 24;
            this.findMeButton.Text = "Find Customer";
            this.findMeButton.UseVisualStyleBackColor = true;
            this.findMeButton.Visible = false;
            this.findMeButton.Click += new System.EventHandler(this.findMeButton_Click);
            // 
            // customersGrid
            // 
            this.customersGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.customersGrid.Location = new System.Drawing.Point(12, 30);
            this.customersGrid.Name = "customersGrid";
            this.customersGrid.RowHeadersWidth = 51;
            this.customersGrid.RowTemplate.Height = 29;
            this.customersGrid.Size = new System.Drawing.Size(10, 464);
            this.customersGrid.TabIndex = 25;
            // 
            // projectsGrid
            // 
            this.projectsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.projectsGrid.Location = new System.Drawing.Point(904, 30);
            this.projectsGrid.Name = "projectsGrid";
            this.projectsGrid.RowHeadersWidth = 51;
            this.projectsGrid.RowTemplate.Height = 29;
            this.projectsGrid.Size = new System.Drawing.Size(10, 464);
            this.projectsGrid.TabIndex = 26;
            // 
            // DatabaseDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1808, 632);
            this.Controls.Add(this.projectsGrid);
            this.Controls.Add(this.customersGrid);
            this.Controls.Add(this.findMeButton);
            this.Controls.Add(this.emailValue);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.phoneValue);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.deleteSelectedProj);
            this.Controls.Add(this.deleteSelected);
            this.Controls.Add(this.findCustomerButton);
            this.Controls.Add(this.refreshProjButton);
            this.Controls.Add(this.projectsListBox);
            this.Controls.Add(this.totalPurchasesValue);
            this.Controls.Add(this.totalPruchasesLabel);
            this.Controls.Add(this.editButton);
            this.Controls.Add(this.refreshListButton);
            this.Controls.Add(this.customerProjectsLabel);
            this.Controls.Add(this.customerProjectsListBox);
            this.Controls.Add(this.customerNIFValue);
            this.Controls.Add(this.customerNIFLAbel);
            this.Controls.Add(this.customerAddressValue);
            this.Controls.Add(this.customerAdressLabel);
            this.Controls.Add(this.customerNameValue);
            this.Controls.Add(this.customerNameLabel);
            this.Controls.Add(this.custListBox);
            this.Controls.Add(this.loadSelectedDetails);
            this.Controls.Add(this.createEntry);
            this.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "DatabaseDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Database Dashboard";
            this.Activated += new System.EventHandler(this.DatabaseDashboard_Activated);
            ((System.ComponentModel.ISupportInitialize)(this.customersGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectsGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button createEntry;
        private Button loadSelectedDetails;
        private ListBox custListBox;
        private Label customerNameLabel;
        private Label customerNameValue;
        private Label customerAddressValue;
        private Label customerAdressLabel;
        private Label customerNIFValue;
        private Label customerNIFLAbel;
        private ListBox customerProjectsListBox;
        private Label customerProjectsLabel;
        private Button refreshListButton;
        private Button editButton;
        private Label totalPruchasesLabel;
        private Label totalPurchasesValue;
        private ListBox projectsListBox;
        private Button refreshProjButton;
        private Button findCustomerButton;
        private Button deleteSelected;
        private Button deleteSelectedProj;
        private Label phoneValue;
        private Label label2;
        private Label emailValue;
        private Label label4;
        private Button findMeButton;
        private DataGridView customersGrid;
        private DataGridView projectsGrid;
    }
}