﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Metrics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using Teste_CBD_Library;
using static System.Windows.Forms.LinkLabel;

namespace CDB_UI
{
    public partial class DatabaseDashboard : Form
    {
        List<CustomerModel> models = SaveProcessor.LoadCustomersFile().ConvertToCustomerModels();
        List<ProjectsModel> loadProjects = SaveProcessor.LoadProjectsFile().ConvertToProjectModels();

        public DatabaseDashboard()
        {
            InitializeComponent();

            WireUpLists();

        }

        private void WireUpLists()
        {
            models = models.OrderBy(x => x.Name).ToList();
            
            //customersGrid.DataSource = models;
            //customersGrid.Columns["Id"].Visible = false;
            //customersGrid.Columns["DisplayDashBoard"].Visible = false;

            custListBox.DataSource = models;
            custListBox.DisplayMember = "Name";

            loadProjects = loadProjects.OrderBy(x=>x.ProjNum).ToList();

            //projectsGrid.DataSource = loadProjects;
            projectsListBox.DataSource = loadProjects;
            projectsListBox.DisplayMember = "ProjectsDisplay";
            
        }

        private void RefreshProjectsList()
        {
            List<ProjectsModel> models = SaveProcessor.LoadProjectsFile().ConvertToProjectModels();

            projectsListBox.DataSource = models;
            projectsListBox.DisplayMember = "ProjectsDisplay";
        } //já não está em utilização

        private void RefreshCustomerList()
        {
            List<CustomerModel> models = SaveProcessor.LoadCustomersFile().ConvertToCustomerModels();

            models = models.OrderBy(x => x.Name).ToList();
            //custListBox.DataSource = null;
            custListBox.DataSource = models;
            custListBox.DisplayMember = "Name";
        } //já não está em utilização

        private void createEntry_Click(object sender, EventArgs e)
        {
            CreateForm frm = new CreateForm();
            frm.Show();
        }

        private void loadSelectedDetails_Click(object sender, EventArgs e)
        {
            CustomerModel cm = (CustomerModel)custListBox.SelectedItem;
            customerNameValue.Text = cm.Name;
            customerAddressValue.Text = cm.Address;
            phoneValue.Text = cm.Phone;
            emailValue.Text = cm.Email;
            customerNIFValue.Text = cm.NIF;
            customerProjectsListBox.DataSource = cm.ProjectList;
            customerProjectsListBox.DisplayMember = "DisplayData";
            
            decimal outputPrice = 0;
            decimal totalPrice = 0;
            for (int i = 0; i < cm.ProjectList.Count; i++)
            {
                totalPrice = cm.ProjectList[i].Price;
                outputPrice = outputPrice + totalPrice;
            }
            
            totalPurchasesValue.Text = outputPrice.ToString();

        } //já não está em utilização

        private void refreshListButton_Click(object sender, EventArgs e)
        {
            List<CustomerModel> models = SaveProcessor.LoadCustomersFile().ConvertToCustomerModels();

            models = models.OrderBy(x => x.Name).ToList();
            //custListBox.DataSource = null;
            custListBox.DataSource = models;
            custListBox.DisplayMember = "Name";
            
        } //já não está em utilização

        private void editButton_Click(object sender, EventArgs e)
        {
            CustomerModel expCustomer = (CustomerModel)custListBox.SelectedItem;
            EditEntry frm = new EditEntry(expCustomer);
            frm.Show();

        }

        private void custListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            CustomerModel cm = (CustomerModel)custListBox.SelectedItem;
            customerNameValue.Text = cm.Name;
            customerAddressValue.Text = cm.Address;
            phoneValue.Text = cm.Phone;
            emailValue.Text = cm.Email;
            customerNIFValue.Text = cm.NIF;
            customerProjectsListBox.DataSource = cm.ProjectList;
            customerProjectsListBox.DisplayMember = "DisplayData";
            decimal outputPrice = 0;
            decimal totalPrice = 0;
            for (int i = 0; i < cm.ProjectList.Count; i++)
            {
                totalPrice = cm.ProjectList[i].Price;
                outputPrice = outputPrice + totalPrice;
            }

            totalPurchasesValue.Text = outputPrice.ToString();
        }

        private void findCustomerButton_Click(object sender, EventArgs e) //não está em utilização
        {
            ProjectsModel projs = (ProjectsModel)projectsListBox.SelectedItem;

            int id = projs.ProjId;

            string wordToSearch = id.ToString();


            MessageBox.Show ($"{File.ReadLines(SaveProcessor.CustomersFilePath()).Any(line => line.Contains(wordToSearch))}");

            //Apenas diz se o projeto está atribuido ou não através de True e False. Não tenho como localizar os clientes apenas com Id.
        }

        private void deleteSelected_Click(object sender, EventArgs e)
        {
            CustomerModel selectedCustomer = (CustomerModel)custListBox.SelectedItem;
            int id = selectedCustomer.Id;

            int counter = 0;
            List<string> lines = SaveProcessor.LoadCustomersFile();
            
            int lineNumber = 0;
            // Read the file and display it line by line.
            foreach (string line in lines)
            {
                string[] cols = line.Split('|');

                if (line.Contains($"{id}|"))
                {
                    lineNumber = counter;
                }
                counter++;
              
            }
            
            lines.RemoveAt(lineNumber);
            File.WriteAllLines(SaveProcessor.CustomersFilePath(), lines.ToArray());

            //Fazer refresh à lista
            RefreshCustomerList();
        }

        private void deleteSelectedProj_Click(object sender, EventArgs e)
        {
            //Primeiro verificar se o cliente só tem 1 projeto! Se tiver, não apaga! Passos:
            //Associar a seleção na ListBox ao customerModel. Como não tenho customerId nos Projects,
            //tenho de verificar se ProjectsList de CustomerModel tem Ids de projetos associados.
            //Fazer o count da prop ProjectsList
            //Se for == 1 não elimina. Se for >1 já deixa apagar.
            //(Opcional)Depois posso fazer com que ao apgar um cliente apague também o projeto por exemplo.
            List<string> custLines = SaveProcessor.LoadCustomersFile();
            List<ProjectsModel> projs = SaveProcessor.LoadProjectsFile().ConvertToProjectModels();
            List<string> projsString = SaveProcessor.LoadProjectsFile();
            int lineNum = 0;
            int projCounter = 0;
            ProjectsModel projNew = (ProjectsModel)projectsListBox.SelectedItem;
            int projId = projNew.ProjId;

            foreach (string line in custLines)
            {
                CustomerModel cm = new();
                string[] cols = line.Split('|');
                cm.Id = int.Parse(cols[0]);
                cm.Name = cols[1];
                cm.Address = cols[2];
                cm.Phone = cols[3];
                cm.Email = cols[4];
                cm.NIF = cols[5];
                //cm.ProjectsList = cols[4];
                string[] projects = cols[6].Split('^');
                
                foreach (string project in projects)
                {
                    string customerProjects = cols[6];
                    string[] projListLine = customerProjects.Split('^');

                    //contar quantos id's tem o cliente para poder atribuir à projListLine[n]
                    int totalLettersCount = 0;
                    int idsCount = 0;
                    totalLettersCount = customerProjects.Length;
                    idsCount = (totalLettersCount + 1) / 2;
                    string eachCustId = "";

                    for (int i = 0; i < idsCount; i++)
                    {
                        
                        eachCustId = projListLine[i];
                        if (projId == int.Parse(eachCustId))
                        {
                            MessageBox.Show("This project is assigned to " + $"{cm.Name}" + " so it can't be deleted.");
                            return;
                        }
                        
                    }
                }
            }

            // Read the file and display it line by line.
            foreach (string lineProj in projsString)
            {
                string[] colsProjs = lineProj.Split('^');

                if (int.Parse(colsProjs[0]) == projId)
                {
                    lineNum = projCounter;

                }
                projCounter++;

                //projs.RemoveAt(lineNum);
            }

            projsString.RemoveAt(lineNum);
            File.WriteAllLines(SaveProcessor.ProjectsFilePath(), projsString.ToArray());
            
            RefreshProjectsList();
        }

        private void refreshProjButton_Click(object sender, EventArgs e)
        {
            List<ProjectsModel> loadProjects = SaveProcessor.LoadProjectsFile().ConvertToProjectModels();
            
            loadProjects = loadProjects.OrderBy(x => x.ProjNum).ToList();
            projectsListBox.DataSource = loadProjects;
            projectsListBox.DisplayMember = "ProjectsDisplay";
        }

        private void findMeButton_Click(object sender, EventArgs e)
        {
            //Já faz esta função no Delete Projet. Encontra o cliente que tem esse projeto. Se não existir apaga o projeto da lista
        }

        private void DatabaseDashboard_Activated(object sender, EventArgs e)
        {
            List<CustomerModel> models = SaveProcessor.LoadCustomersFile().ConvertToCustomerModels();

            models = models.OrderBy(x => x.Name).ToList();
            
            custListBox.DataSource = models;
            custListBox.DisplayMember = "Name";

            List<ProjectsModel> loadProjects = SaveProcessor.LoadProjectsFile().ConvertToProjectModels();

            loadProjects = loadProjects.OrderBy(x => x.ProjNum).ToList();
            projectsListBox.DataSource = loadProjects;
            projectsListBox.DisplayMember = "ProjectsDisplay";

            //faz refresh automaticamente mas só apresenta 1 projeto na ProjectList
            //porque agora ele só lê 1 valor em cm.ProjectsList (por ter adicionado o ProjectName)
        }
    }
}
