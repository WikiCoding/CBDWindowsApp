namespace DB_UI
{
    public partial class DatabaseDashboard : Form
    {
        public DatabaseDashboard()
        {
            InitializeComponent();
        }

        //private void Form1_Load(object sender, EventArgs e)
        //{

        //}
    }
}