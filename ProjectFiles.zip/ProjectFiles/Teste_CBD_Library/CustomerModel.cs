﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teste_CBD_Library
{
    public class CustomerModel
    {
        public int Id { get; set; }
        
        public string Name { get; set; }

        public string Address { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public string NIF { get; set; }

        public List<ProjectsModel> ProjectList { get; set; } = new List<ProjectsModel>();

        public string DisplayDashBoard
        {
            get
            {
                return $"{Id} -> {Name}";
            }
        }

    }
}
