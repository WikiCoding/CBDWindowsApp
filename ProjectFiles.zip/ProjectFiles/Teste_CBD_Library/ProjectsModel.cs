﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Teste_CBD_Library
{
    public class ProjectsModel
    {
        public int ProjId { get; set; }

        public string ProjNum { get; set; }

        public string ProjName { get; set; }

        public decimal Price { get; set; }

        public string registryTime { get; set; }

        public string DisplayData
        {
            get
            {
                return $"{ProjNum}->{ProjName}->{Price}->{registryTime}";
            }
        }

        public string ProjectsDisplay
        {
            get
            {
                return $"{ProjNum}->{ProjName}->{registryTime}";
            }
        }

        public string ProjectsIdName
        {
            get
            {
                return $"{ProjNum}^{ProjName}";
            }
        }
    }
}
