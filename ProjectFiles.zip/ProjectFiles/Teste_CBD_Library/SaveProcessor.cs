﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teste_CBD_Library
{
    public static class SaveProcessor
    {

        public static string CustomersFilePath()
        {
            //return @$"C:\Users\tiago\Desktop\Meus_Programas\Final_CDB\Teste_CBD\Customers.txt";
            //return $@"C:\Users\tiago\Desktop\G3DP\BD_Clientes_v2\Customers.txt";
            return $@"Customers.txt";
        }

        public static List<string> LoadCustomersFile()
        {
            if (!File.Exists(CustomersFilePath()))
            {
                return new List<string>();
            }

            return File.ReadAllLines(CustomersFilePath()).ToList();
        }

        public static string ProjectsFilePath()
        {
            //return @$"C:\Users\tiago\Desktop\Meus_Programas\Final_CDB\Teste_CBD\Projects.txt";
            //return $@"C:\Users\tiago\Desktop\G3DP\BD_Clientes_v2\Projects.txt";
            return $@"Projects.txt";
        }

        public static List<string> LoadProjectsFile()
        {
            if (!File.Exists(ProjectsFilePath()))
            {
                return new List<string>();
            }

            return File.ReadAllLines(ProjectsFilePath()).ToList();
        }
        public static List<ProjectsModel> ConvertToProjectModels(this List<string> lines)
        {

            List<ProjectsModel> output = new List<ProjectsModel>();
            foreach (string line in lines)
            {
                string[] cols = line.Split('^');
                ProjectsModel p = new ProjectsModel();
                p.ProjId = int.Parse(cols[0]);
                p.ProjNum = cols[1];
                p.ProjName = cols[2];
                p.Price = decimal.Parse(cols[3]);
                p.registryTime = cols[4];

                output.Add(p);

            }
            return output;
        }

        public static List<CustomerModel> ConvertToCustomerModels(this List<string> lines)
        {

            List<CustomerModel> output = new List<CustomerModel>();
            List<ProjectsModel> projs = LoadProjectsFile().ConvertToProjectModels();
            //Ele só consegue passar uma string para a List<ProjectsModel> daí ter só necessário o convert!

            foreach (string line in lines)
            {
                string[] cols = line.Split('|');
                CustomerModel cm = new CustomerModel();
                cm.Id = int.Parse(cols[0]);
                cm.Name = cols[1];
                cm.Address = cols[2];
                cm.Phone = cols[3];
                cm.Email = cols[4];
                cm.NIF = cols[5];
                //cm.ProjectsList = cols[4];
                string[] projects = cols[6].Split('^'); //Já aqui não puxa os 2 projetos que lá tenho...
                //provavelmente aqui tenho de fazer como em EditEntry. Criar uma List<CustomerModel> e fazer um for loop
                

                foreach (string id in projects)
                {
                    //cm.ProjectList.Add(projs.Where(x => $"{x.ProjId}^{x.ProjName}" == id).First());
                    cm.ProjectList.Add(projs.Where(x => x.ProjId == int.Parse(id)).First());
                    //expressão antiga em que ia procurar apenas pelo ProjId!
                    //só carrega 1 projeto por cliente agora porque só estamos a ler o 1º item de cm.ProjectList
                }

                output.Add(cm);
            }
            return output;
        }
        public static void SaveToProjectsFile(this List<ProjectsModel> models)
        {
            List<string> lines = new List<string>();
            foreach (ProjectsModel p in models)
            {
                lines.Add($"{p.ProjId}^{p.ProjNum}^{p.ProjName}^{p.Price}^{p.registryTime}");
            }
            File.WriteAllLines(ProjectsFilePath(), lines);
        }
        private static string ConvertProjectListToString(List<ProjectsModel> projects)
        {
            //este método é por causa do ultimo valor do TeamModel aka CustomerModel
            //trocar assim o valor dos numeros separados por 1 | 2 | 3 por strings
            string output = "";

            if (projects.Count == 0)
            {
                return "";
            }

            foreach (ProjectsModel p in projects)
            {
                //output += $"{p.ProjId}^{p.ProjName}|";
                output += $"{p.ProjId}^";
                //aqui tereamos algo assim como resultado
                // 2|5|6|
                //o último | está a mais.
            }

            //auqi estamos a retirar o último |
            //o valor 0 significa a primeira posição da Array
            output = output.Substring(0, output.Length - 1);
            //output.Length dá o nº total de caracteres
            //isso -1 devolve a Substring escrita sem o |

            return output;

        }
        public static void SaveToCustomerFile(this List<CustomerModel> models)
        {
            List<string> lines = new List<string>();

            foreach (CustomerModel cm in models)
            {
                lines.Add($"{cm.Id}|{cm.Name}|{cm.Address}|{cm.Phone}|{cm.Email}|{cm.NIF}|{ConvertProjectListToString(cm.ProjectList)}");
            }

            File.WriteAllLines(CustomersFilePath(), lines);
        }

    }
}
